using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Pecera.Core;

namespace PeceraNF
{
    // Contenedor unico del estado del mod. HILOS:
    //   - Memoria, AlmacenFichas, RegistroIds, Evidence, Compuerta, CupoVoz, SaludLlm,
    //     PoliticaInfluencia: internamente sincronizados (cualquier hebra).
    //   - Afectos, Secretos, Cronica, Costumbres: SOLO el hilo principal (hook y Update).
    public static class Estado
    {
        public const string VERSION = "0.5.0";

        public static string Datos = "";
        public static PeceraConfig Cfg = PeceraConfig.Parse("");
        public static IClock Reloj = new SystemClock();
        public static IStorage Disco;
        public static Evidence Ev;
        public static RegistroIds Ids;
        public static AlmacenFichas Fichas;
        public static Memoria Mem;
        public static ModeloAfectivo Afectos;
        public static RedSecretos Secretos;
        public static Compuerta Compuerta;
        public static SaludLlm Salud;
        public static CupoVoz Voz;
        public static CupoVoz Resumen;
        public static PoliticaInfluencia Influencia;
        public static Cronica Cronica;
        public static Costumbres Costumbres;
        public static Cultura Cultura;
        public static AlmacenPersonas Personas;
        public static Normas Normas = new Normas();
        public static FrenoConversacion Freno = new FrenoConversacion();
        public static Director Director;
        public static string UltimaSugerencia = "";
        public static Agenda Agenda;
        public static PresupuestoLlm Presupuesto;
        public static MetasReino Metas = new MetasReino();
        // v0.5 Vida (solo hilo principal): bus de sucesos, psique, prejuicio de grupo, gustos del jugador, maestro de juego, ordenes.
        public static BusEventos Eventos = new BusEventos();
        public static Prejuicios Prejuicios = new Prejuicios();
        public static Preferencias Prefs = new Preferencias();
        public static RecuerdosFuertes Fuertes = new RecuerdosFuertes();
        public static Linaje Linaje = new Linaje();
        public static MaestroDeJuego Maestro;
        public static Ordenes Ordenes = new Ordenes();
        public static string OrdenesTexto = "";
        // Solo hilo principal: se rellenan al escribir el informe y se leen en el hook.
        public static readonly Dictionary<string, string> FaccionDe = new Dictionary<string, string>();
        public static readonly Dictionary<string, Dialecto> Dialectos = new Dictionary<string, Dialecto>();
        public static CatalogoEsquemas Catalogo = new CatalogoEsquemas();
        public static Directrices Dir = new Directrices();
        public static volatile bool Activo = true;
        public static volatile bool EscrituraSegura = true;   // false si cambio la version del juego
        public static string VersionJuego = "";
        public static readonly List<string> Avisos = new List<string>();
        public static long ArranqueTicks;

        public static void Inicia(string datos)
        {
            Datos = datos;
            Directory.CreateDirectory(datos);
            ArranqueTicks = Reloj.NowTicks;
            Ev = new Evidence(Reloj);
            Criterios();

            string ruta = Path.Combine(datos, "config.txt");
            string texto = File.Exists(ruta) ? File.ReadAllText(ruta, new UTF8Encoding(false)) : null;
            if (texto == null)
            {
                Escribe(ruta, PeceraConfig.RenderDefault());
            }
            else if (PeceraConfig.VersionDe(texto) < PeceraConfig.VersionActual)
            {
                var cambios = new List<string>();
                File.Copy(ruta, Path.Combine(datos, "config.v1.bak.txt"), true);
                Escribe(ruta, PeceraConfig.Migra(texto, cambios));
                Avisos.Add("config.txt migrado a la version 2 (copia en config.v1.bak.txt)");
                foreach (var c in cambios) Avisos.Add("config: " + c);
                texto = File.ReadAllText(ruta, new UTF8Encoding(false));
            }
            Cfg = PeceraConfig.Parse(File.ReadAllText(ruta, new UTF8Encoding(false)));
            foreach (var a in Cfg.Avisos) Avisos.Add("config: " + a);
            Escribe(Path.Combine(datos, "config.defecto.txt"), PeceraConfig.RenderDefault());

            string dd = Cfg.Str("datos_dir");
            if (dd.Length > 0) { Datos = dd; Directory.CreateDirectory(dd); }
            Disco = new DiskStorage(Datos, 5 * 1024 * 1024);
            Activo = Cfg.Bool("activo");

            Ids = new RegistroIds(Disco);
            Fichas = new AlmacenFichas(Disco);
            Mem = new Memoria(Disco, Reloj) { MaxRecientes = Cfg.Int("memoria_recientes") };
            if (Mem.LineasCorruptas > 0) Avisos.Add("memoria.jsonl: " + Mem.LineasCorruptas + " lineas ilegibles ignoradas");
            Afectos = new ModeloAfectivo(id => { var f = Fichas.Get(id); return f != null ? f.Rencor : 0.5; });
            Afectos.Carga(Disco.ReadLines("afectos.jsonl"));
            Secretos = new RedSecretos(Afectos, id => Fichas.Get(id), Reloj, new Rng(Environment.TickCount));
            Compuerta = new Compuerta(Reloj)
            {
                VentanaVetoSegundos = Cfg.Int("peticiones_veto_s"),
                DiaTicks = (long)(Cfg.Num("dia_segundos") * TimeSpan.TicksPerSecond)
            };
            Compuerta.FijaTopeDia("esquema", Cfg.Int("esquemas_dia_max"));
            Compuerta.FijaTopeDia("peticion", Cfg.Int("peticiones_dia_max"));
            Salud = new SaludLlm(Reloj);
            Voz = new CupoVoz(Reloj, Cfg.Int("gap_voz"));
            Resumen = new CupoVoz(Reloj, Cfg.Int("resumen_gap_s"));
            Influencia = new PoliticaInfluencia(Reloj)
            {
                Max = Cfg.Num("influencia_max"),
                ParejaSegundos = Cfg.Int("influencia_pareja_s"),
                HoraMax = Cfg.Int("influencia_hora_max")
            };
            Cronica = new Cronica();
            Costumbres = new Costumbres();
            Cultura = new Cultura();
            Personas = new AlmacenPersonas(Disco);
            if (Personas.LineasCorruptas > 0) Avisos.Add("personas.jsonl: " + Personas.LineasCorruptas + " lineas ilegibles ignoradas");
            Agenda = new Agenda();
            string est = Cfg.Str("director_estilo").ToLowerInvariant();
            if (est == "calmo" || est == "clasico" || est == "caotico")
                Director = new Director(Environment.TickCount) { Estilo = est == "calmo" ? EstiloDirector.Calmo : est == "caotico" ? EstiloDirector.Caotico : EstiloDirector.Clasico };
            Presupuesto = new PresupuestoLlm(Reloj) { LlamadasPorDia = Cfg.Int("agentes_llm_dia"), DiaTicks = (long)(Cfg.Num("dia_segundos") * TimeSpan.TicksPerSecond) };

            string esq = Path.Combine(Datos, "esquemas.txt");
            if (File.Exists(esq)) Catalogo = CatalogoEsquemas.Parse(File.ReadAllText(esq, new UTF8Encoding(false)));
            foreach (var a in Catalogo.Avisos) Avisos.Add("esquemas.txt: " + a);
            IniciaVida();
            CargaDirectriz();
        }

        // Bus de vida + maestro + persistencia del estado social (mundo.jsonl). Todo interno: nada de esto escribe en el juego.
        static void IniciaVida()
        {
            Maestro = new MaestroDeJuego
            {
                Afectos = Afectos, Persona = id => Personas.Get(id), Nombre = id => Ids.Nombre(id), Freno = Freno, Mem = Mem, Fuertes = Fuertes,
                Secretos = Cfg.Bool("rumores") ? Secretos : null
            };
            Vida.Conecta(Eventos, new ContextoVida
            {
                Afectos = Afectos, Mem = Mem, Cronica = Cronica, Linaje = Linaje, Fuertes = Fuertes,
                Persona = id => Personas.Get(id), Nombre = id => Ids.Nombre(id), Vivos = VivosIds
            });
            // El reino aprende de tus vetos: cada decision de la Compuerta (vetada o no) alimenta las preferencias.
            // Compuerta.AlDecidir se invoca fuera de su cerrojo, pero desde la hebra que llama a Veta/Listas: se pasa al hilo principal.
            Compuerta.AlDecidir = (d, vetada) => { string c = d.Clase, e = d.Etiqueta; Principal.Encola(delegate { Prefs.Registra(c, e, vetada); }); };
            var es = Social();
            bool futura;
            int malas = es.Carga(Disco.ReadLines("mundo.jsonl"), out futura);
            if (futura) { Avisos.Add("mundo.jsonl es de una version MAS NUEVA del mod: no se carga ni se sobrescribe"); MundoBloqueado = true; }
            if (malas > 0) Avisos.Add("mundo.jsonl: " + malas + " lineas ilegibles ignoradas");
            Prejuicios.Atenuacion = Normas.AtenuacionPrejuicio;
        }

        public static bool MundoBloqueado;

        public static List<string> VivosIds()
        {
            var ids = new List<string>();
            foreach (var f in Fichas.Todas()) ids.Add(f.Id);
            ids.Sort(StringComparer.Ordinal);
            return ids;
        }

        public static EstadoSocial Social()
        {
            return new EstadoSocial { Agenda = Agenda, Normas = Normas, Director = Director, Cultura = Cultura, Cronica = Cronica, Costumbres = Costumbres,
                                      Secretos = Cfg.Bool("rumores") ? Secretos : null, Fuertes = Fuertes, Exp = Maestro != null ? Maestro.Exp : null, Prefs = Prefs, Prejuicios = Prejuicios };
        }

        // Hilo principal. Reescritura atomica (DiskStorage.Rewrite) de todo el estado social.
        public static void GuardaMundo()
        {
            if (MundoBloqueado || Disco == null) return;
            Disco.Rewrite("mundo.jsonl", Social().Serializa());
        }

        static void Criterios()
        {
            // minimo de exitos y maximo de fallos para considerar cada funcion verificada EN PARTIDA.
            Ev.Criterio("hook_opinion", 50, 0);
            Ev.Criterio("voz_frase", 5, 2);
            Ev.Criterio("voz_json_valido", 5, 3);
            Ev.Criterio("bocadillo_dibujado", 5, 0);
            Ev.Criterio("empujon_opinion", 3, 0);
            Ev.Criterio("reentrada_bloqueada", 1, 0);   // informativa: sin_datos = el juego no reentra
            Ev.Criterio("memoria_persistida", 1, 0);
            Ev.Criterio("memoria_resumen_llm", 1, 1);
            Ev.Criterio("id_clave_estable", 1, 0);
            Ev.Criterio("afectos_modelo", 20, 0);
            Ev.Criterio("rumor_fuga", 1, 0);
            Ev.Criterio("sonda_pawn", 1, 0);
            Ev.Criterio("agentes_plan_reglas", 10, 0);          // el plan por reglas se ejecuta sin excepciones
            Ev.Criterio("agentes_plan_llm", 3, 6);               // el LLM devuelve planes validos (algun fallo es normal)
            Ev.Criterio("agentes_intencion_observada", 1, 0);
            Ev.Criterio("agentes_reflexion", 1, 0);              // la importancia acumulada dispara conclusiones    // el juego produjo el evento que una intencion esperaba
            Ev.Criterio("peticion_capturada", 1, 0);   // Rey dormido: vimos una peticion real en cola (fase 1)
            Ev.Criterio("peticion_aplicada", 1, 0);    // Rey dormido: aplicamos Complete() real (fase 2)
            Ev.Criterio("informe_escrito", 1, 0);
            Ev.Criterio("vida_maestro", 5, 0);         // el maestro resolvio conversaciones internas sin excepciones
            Ev.Criterio("vida_crisis", 1, 0);          // informativa: alguna crisis por estres (sin_datos = nadie llego a 100)
            Ev.Criterio("vida_suceso", 1, 0);          // un gancho de ganchos.txt publico un suceso de vida real
            Ev.Criterio("mundo_persistido", 1, 0);
        }

        // Ordenes del soberano en lenguaje natural (solo las lineas sin # de directriz.txt). Mueven normas, director y consejo INTERNOS.
        static void AplicaOrdenes(string texto)
        {
            var sb = new StringBuilder();
            foreach (var l in texto.Split('\n')) { string t = l.Trim(); if (t.Length > 0 && t[0] != '#' && t[0] != '[') sb.Append(t).Append(' '); }
            string limpio = sb.ToString().Trim();
            if (limpio == OrdenesTexto) return;
            OrdenesTexto = limpio;
            Ordenes = Ordenes.Parse(limpio);
            int dia = Gancho.DiaActual();
            var cambios = new List<string>();
            Normas.Fuerza(Ordenes.NormaForzada, dia, cambios);
            foreach (var c in cambios) Cronica.Anota(dia, "orden", c, 6);
            Prejuicios.Atenuacion = Normas.AtenuacionPrejuicio;
            if (Director != null)
            {
                Director.FiestaPedida = Ordenes.PideFiesta;
                if (Ordenes.Estilo.HasValue) Director.Estilo = Ordenes.Estilo.Value;
                var o = Ordenes;
                Director.Protegido = id => o.Favorece(Ids.Nombre(id), FaccionNombre(id));
            }
            if (Ordenes.Entendidas.Count > 0)
            {
                string msg = "El soberano ordena: " + string.Join(", ", Ordenes.Entendidas.ToArray());
                Cronica.Anota(dia, "orden", msg, 6);
                Avisos.Add(msg);
            }
        }

        static string FaccionNombre(string id) { string f; return FaccionDe.TryGetValue(id, out f) ? f : null; }

        public static void Escribe(string ruta, string texto)
        {
            File.WriteAllText(ruta, texto, new UTF8Encoding(false));
        }

        static string _dirTexto = "";
        static DateTime _dirFecha = DateTime.MinValue;

        // directriz.txt se relee solo cuando cambia (por fecha de modificacion).
        public static void CargaDirectriz()
        {
            try
            {
                string r = Path.Combine(Datos, "directriz.txt");
                if (!File.Exists(r))
                {
                    Escribe(r, "# Escribe aqui lo que quieres que pase en el reino. Se lee solo, sin reiniciar.\r\n" +
                               "# Admite secciones: [faccion:Casa de Ana] y [pawn:Ana]. Las lineas con # se ignoran.\r\n");
                    return;
                }
                DateTime t = File.GetLastWriteTimeUtc(r);
                if (t == _dirFecha) return;
                _dirFecha = t;
                _dirTexto = File.ReadAllText(r, new UTF8Encoding(false));
                Dir = Directrices.Parse(_dirTexto);
                if (Cfg.Bool("ordenes")) AplicaOrdenes(_dirTexto);
            }
            catch (IOException e) { Avisos.Add("directriz.txt ilegible: " + e.Message); }
        }
    }
}
