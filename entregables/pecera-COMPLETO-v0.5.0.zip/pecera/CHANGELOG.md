# Changelog

## 0.5.0 (2026-10-08) — «Vida»: los pawns viven por dentro (CK3, Dwarf Fortress, The Sims, Concordia, Voyager + datos reales)

Todo **HECHO-NUBE** (274 tests, simulador, stubs con 0 avisos) y **NO VERIFICADO en partida**. **Nada escribe en el estado del juego**: todo es interno
(modelo afectivo, agenda, crónica, bocadillos). Fuentes: `docs/INVESTIGACION.md` §5.
- **Calibración con tus 300 eventos reales** (`Calibracion`): la magnitud de un cambio de opinión se mapea por percentiles reales (p50 0.72, p90 1.96, p99 2.36),
  y el 93 % de eventos «por rasgo» se modela como lo que es: **prejuicio de grupo** (`Prejuicios`), aprendido de los propios motivos del juego («es Orco», «está Malo»),
  que decae (τ 120 d), no cuenta dentro del propio grupo, se atenúa a la mitad con la norma de tolerancia y sesga con quién se acerca cada pawn.
- **Psique** (`Psique.cs`): recuerdos fuertes 8 + 8 por categoría con promoción a largo plazo y revividos que estresan o reconfortan y derivan la personalidad
  (±0.2 máx., Dwarf Fortress); **estrés por niveles** (CK3): actuar contra el carácter, fracasar, el duelo y las heridas estresan; al cruzar un nivel hay **crisis
  según carácter** (irascible → arrebato contra quien peor le cae; frágil → hundimiento; resto → retiro) que libera estrés; el estresado evita aún más lo que va contra
  su naturaleza. **Experiencia** (Voyager): tasa de éxito por tipo de intención y currículo de ambiciones de dos caminos. **Elección** (The Sims): al azar entre las mejores (softmax).
- **Bus de sucesos + `Vida`**: muerte (duelo proporcional al vínculo, rencor al causante), nacimiento, boda (cumple «casarse»), herida, llegada/partida.
- **Maestro de juego** (Concordia): resuelve por dentro las intenciones sociales y deja al juego (con sus interruptores) lo que no es suyo.
- **El reino aprende de ti**: cada veto o aceptación de la Compuerta ajusta `Preferencias`; lo que vetas siempre (≥ 3 veces) deja de proponerse.
- **Órdenes en lenguaje natural** en `directriz.txt` («quiero paz», «ojo por ojo», «favorece a Ana», «haced una fiesta», «quiero drama/calma»).
- **`mundo.jsonl`**: agenda, normas, director, cultura, crónica, costumbres, secretos, recuerdos, experiencia, preferencias y prejuicios sobreviven al reinicio
  (reescritura atómica; un fichero de versión futura no se toca).
- **`ganchos.txt` + `ganchos.sugeridos.txt`**: observadores de solo lectura sobre métodos que tú confirmes (`ganchos=0` por defecto) para que la vida oiga muertes, bodas y nacimientos reales.
- El hook alimenta el modelo con **todos** los eventos (antes el freno de 20 s por pawn descartaba datos del modelo afectivo).
- Simulador: población viva (nacimientos, mayoría de edad, bodas, inmigración, muertes), jugador simulado con gustos, órdenes a mitad de partida y comprobación de ida y vuelta de la persistencia.
- Config nueva: `vida`, `vida_maestro`, `vida_maestro_dia`, `ordenes`, `ganchos`.

## 0.4.0 (2026-10-08) — Fase 3 ampliada tras investigar Generative Agents, RimWorld, Project Sid, alife-sdk, AI Town e IAUS

Todo **HECHO-NUBE** (249 tests, simulador) y **NO VERIFICADO en partida**. Nada escribe en el juego. Fuentes, adopciones y limites: `docs/INVESTIGACION.md`.
- **Memoria**: `Recupera` (recencia 0.5 / relevancia 3 / importancia 2) y reflexion por importancia acumulada con conclusiones guardadas como recuerdos; la voz del juego recupera por relevancia.
- **Planes de varios pasos** (`Guiones`) y ambiciones que llevan tiempo (plazo minimo 20/60/150 dias) con sucesion de ambiciones (`Agente.Sucesora`): 16–18 cumplidas al anio entre 24 pawns (antes 80–140 triviales).
- **Animo y rupturas** al estilo RimWorld (+ inspiracion), **Director de drama** (3 estilos), **Normas** (paz publica / ojo por ojo / hospitalidad) con histeresis, **roles emergentes**, **etapas de relacion**, **freno de conversacion por pareja**, **curvas IAUS**, `RedSecretos.Escandalo`.
- `Mente` (juego): reflexion, sucesion de ambiciones, normas y sugerencias del director; `agentes.md` muestra animo, rol, normas, tension y la ultima sugerencia. `director_estilo` en config.
- Hallazgos del simulador que cambiaron el diseno: ambiciones triviales (los planes de 3 pasos se cumplian en 3 dias), animo base demasiado bajo (40 % de pawns-dia bajo el umbral), director sin actuadores (la tension no se movia) y normas que parpadeaban.

## 0.3.0 (2026-10-08) — agentes con proposito (respuesta al PROMPT_OPUS, Fase 0 y 1 en la nube)

Todo **HECHO-NUBE** (tests + simulador, 219 tests) y **NO VERIFICADO en partida**. Nada de esto escribe en el juego.
- `Persona`, `Agenda`, `Agente` (reflexion → plan → consolida), `Planificador` con guardarrailes (`Valida`) que valen tambien para el LLM, `PlanLlm` en lote,
  `PresupuestoLlm` (techos por prioridad), `Dialogo` (resultado por reglas, texto por LLM), `Narrador` (historias). Detalle y plan: `docs/PLAN_OPUS.md`.
- `Game/Mente.cs` (`agentes=1`, apagado por defecto): plan por reglas por trozos, lote al LLM con presupuesto, intenciones dadas por hechas al VER el evento en el juego;
  salidas `agentes.md` y `historias.md`; burbuja de intencion (max 1 por ronda).
- Identidad por tokens + unicidad en vivo (`Core/NombreMiembro.cs`); F11 escribe tambien `sonda_mundo.json` (managers de reloj/reino/necesidades + metodos de Pawn).
- Simulador con agentes (24 pawns, 360 dias, LLM simulado que se equivoca a proposito) y 7 tests de criterios de aceptacion.
- Calibraciones halladas con el simulador: necesidades (con el ritmo inicial todos acababan agotados), enfriamientos de peticiones/venganzas/consuelos (sin ellos ~2000 peticiones al anio).

## 0.2.2 (2026-10-08) — traspaso a Opus: se integra el estado real del PC y se endurece el Rey dormido

- Integrado en el repo lo hecho en el PC del usuario (0.2.1 + Rey dormido fases 1 y 2): `Peticiones.cs`, sonda de peticiones, `panel_inicio`,
  `PeceraConfig.VersionDe`, arreglo de `perdona`. El `.rar` del traspaso llego **danado** (17 ficheros vacios); se conservan las versiones intactas del repo
  para `compilar.ps1`, `ConfigTests.cs` y `SistemasTests.cs` y se recrearon los tests de `VersionDe`.
- **Nuevo interruptor `peticiones_aplicar` (0 por defecto).** Antes la fase 2 se activaba sola al ver una peticion en la cola; eso prueba que *leer* funciona,
  no que `Receive()+Complete()` sea inocuo. Ahora hacen falta tres llaves (interruptor explicito + evidencia + escritura segura). `peticiones=1` solo observa.
- Corregido: el dry-run del consejo anotaba la cola ENTERA en la cronica cada 30 s; ahora solo las peticiones nuevas.

## 0.2.1 (2026-10-07) — primera verificacion en el PC real (opencode/Claude local)

**VERIFICADO en el PC del usuario (Windows 10, csc.exe de .NET Framework 4, Noble Fates 0.31.5.3):**
- `compilar.ps1` compila los 29 ficheros con `-warnaserror`, **0 avisos**, 149,5 KB (v0.2.0).
- 159 tests en verde con un SDK .NET 8.0.425 portatil (`C:\Users\Jose Luis\.pecera-tools\dotnet`), no solo en la nube.
- `stubs/Pecera.Game.Check` compila sin avisos; el simulador (360 dias, semilla 1) reproduce el informe de la sesion.
- El plugin carga en el juego real: `Loading [Pecera NobleFates 0.2.0]`, `parcheado: PawnManager.OpinionDelta`, panel listo, sin excepciones.

### Corregido
- **BUG (grave, no cubierto por los 159 tests): la migracion del config v1 nunca se ejecutaba.**
  `Estado.Inicia` decidia migrar con `Parse(texto).Int("config_version") < 2`, pero `Str()` devuelve el DEFECTO del esquema
  (2) cuando la clave falta, asi que un `config.txt` antiguo parecia ya migrado y `influencia=1` (sin verificar, escribe en
  el juego) seguia activa. Nuevo `PeceraConfig.VersionDe(texto)` (1 si no hay clave) + 3 tests de regresion (162 en total).
  **VERIFICADO en el juego:** ahora el log dice `config.txt migrado a la version 2`, `influencia=1 -> 0`, y existe `config.v1.bak.txt`.

- **BUG de semantica en `PoliticaInfluencia`:** `perdona` invertia el signo siempre, tambien con delta positivo, y restaba
  estima a quien acababa de hacer algo bueno. Medido con qwen4b real (12 casos, prompts reales del Core): 3 de 5 eventos
  positivos devolvian `perdona`. Ahora `perdona` solo actua con delta negativo. Test anadido (162 en total).

### Verificado con el modelo real (sin el juego)
- Prompts, `OllamaWire` y `ReplicaParser` del Core contra qwen4b-silly en Ollama: 12/12 frases utiles, 12/12 JSON limpio,
  latencia mediana 1,4 s (max 1,8 s). Cliente de prueba fuera del repo (`%TEMP%\pecera_e2e`).

### Todavia NO VERIFICADO en partida
Bocadillos, empujon de opinion, reentrada, id estable, memoria entre reinicios, A/B de coste: ver `VERIFICACION_PENDIENTE.md`.

## 0.2.0 (2026-10-07) — capas, pruebas, simulador e ideas

Todo lo siguiente esta **probado en la nube (tests + simulador)** y es **NO VERIFICADO en partida** salvo lo indicado.

### Nuevo
- **Arquitectura por capas**: `Pecera.Core` (logica pura, C# 5), `Pecera.Game` (adaptadores), tests, simulador y stubs de tipos.
- **A. Base verificable**: parser JSON propio con escapes, `\uXXXX`, vallas markdown, prosa alrededor y reparacion de JSON truncado;
  cliente Ollama probado (cuerpos nativo/proxy y lectura de respuesta); configuracion tipada y documentada con migracion de v1;
  rutas parametrizadas (`compilar.ps1` busca Steam; `datos_dir`).
- **B. Identidad y persistencia**: id estable por pawn (clave del juego si existe, si no nombre + separacion de homonimos),
  fichas (rasgos, metas, miedos, voz, carisma, rencor, locuacidad) con generacion determinista sin LLM, memoria episodica
  `recientes -> medio -> largo` con resumen del LLM, fallback sin LLM, poda dura, compactacion y recuperacion de lineas corruptas.
- **C. Emociones y relaciones**: afecto, confianza, rencor, deuda, rivalidad, romance y trauma por pareja dirigida; decaimiento,
  reconciliacion, gratitud; estabilidad demostrada por construccion y por test de propiedades.
- **D. Secretos y rumores**: confidencias, propagacion con distorsion, consecuencias afectivas, `fugas.jsonl`, metricas de la red.
- **E. Esquemas**: catalogo `esquemas.txt` con clases de seguridad, motor de propuestas (rencor sostenido / romance). *Adaptador al juego: pendiente.*
- **F. Sociedad**: facciones, liderazgo por carisma, favores, parejas, costumbres/tradiciones, soledad, deriva de personalidad acotada.
- **G/H. Gobierno y crecimiento**: consejo (peticiones, investigacion), metas con bucle de deficit, metricas del reino.
  *Adaptadores al juego: pendientes.*
- **I. Direccion del jugador**: directrices global/faccion/pawn, consola por fichero con deshacer, `modo` observador/asistente/dios.
- **J. Cronica** con hitos, resumen por temporada y leyendas.
- **K. Observabilidad**: `verificacion.json` (evidencia por funcion con criterio), `informe.md`, grafo DOT/JSON, estadistica de FPS, A/B formal (`pecera_ab.py`).
- **L. Robustez**: disyuntor del LLM (modo degradado), guarda de version del juego, formato de datos versionado, escritura atomica.
- **Compuerta de decisiones**: tope diario, enfriamiento y **ventana de veto** para toda escritura al juego.
- Sondas de solo lectura (F11) para cerrar firmas pendientes.

### Ideas anadidas (Core + tests + simulador; ninguna escribe en el juego)
- **Justicia** (`Tribunal`), **sucesion y herencia** (`Linaje`, `Sucesion`), **mentoria**, **cultura/religion emergente** (`Cultura`), **dialectos**,
  **estaciones**, **suenos e inspiraciones**, **espionaje**, **deriva de personalidad** en el simulador.
- Cableado ligero en el juego (sin escribir): facciones, dialectos en el prompt de la voz, credo en el informe.
- `Ficha.Ambicion` (opcional; las fichas antiguas se leen con 0.5). `compilar.ps1` pasa `-codepage:65001` (los literales con tildes del Core ya no dependen de la pagina de codigos).

### Cambiado
- `influencia` pasa a **0 por defecto** (v0.1 la llevaba a 1 sin haberse verificado). La migracion lo apaga y lo avisa.
- Empujones: ademas del tope por frase y la pareja, **tope por hora** (`influencia_hora_max`).
- El hook alimenta tambien el modelo afectivo y la memoria; sigue sin esperar nunca al LLM.
- `OnGUI`/panel conservados de v0.1; los bocadillos dejan evidencia de haberse dibujado.

### Arreglado
- La memoria de v0.1 era por nombre y solo en RAM (informe §9 fase 2: colisiones de nombre): ahora por id y en disco. *Sin ver en partida.*

### Conocido / pendiente
- Ver `VERIFICACION_PENDIENTE.md` y `01_INFORME_PECERA.md` §8.

## 0.1.0
Plugin inicial (`legacy/noble-fates-0.1`): hook verificado, frases, bocadillos, memoria RAM, influencia, directrices.
